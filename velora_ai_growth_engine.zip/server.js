
const express = require("express");
const fs = require("fs");
const bodyParser = require("body-parser");

const app = express();
app.use(bodyParser.json());
app.use(express.static("public"));

const ADMIN_PASSWORD = "Loving103$";

function readDB(){
  try {
    return JSON.parse(fs.readFileSync("./data/db.json","utf8"));
  } catch(e){
    return {revenue:0,storeActive:true,orders:[]};
  }
}

function saveDB(db){
  fs.writeFileSync("./data/db.json", JSON.stringify(db,null,2));
}

// admin login
app.post("/admin/login",(req,res)=>{
  res.json({success:req.body.password === ADMIN_PASSWORD});
});

// dashboard
app.get("/admin/data",(req,res)=>{
  res.json(readDB());
});

// toggle store
app.post("/admin/toggle",(req,res)=>{
  const db = readDB();
  db.storeActive = !db.storeActive;
  saveDB(db);
  res.json(db);
});

// products
app.get("/products",(req,res)=>{
  res.json([
    {name:"Luxury Smart Mirror",price:129.99},
    {name:"AI Beauty Mask",price:59.99},
    {name:"Glow Fitness Tracker",price:89.99}
  ]);
});

// AI engine endpoints
app.get("/ai/products",(req,res)=>{
  res.json([
    {name:"Luxury Smart Mirror",price:129.99,score:92},
    {name:"AI Beauty Mask",price:59.99,score:87},
    {name:"Glow Fitness Tracker",price:89.99,score:78}
  ]);
});

app.get("/ai/content",(req,res)=>{
  res.json({
    ad:"Upgrade your lifestyle with luxury AI tech.",
    tiktok:"This AI gadget is going viral for a reason...",
    email:"New luxury drop just launched — limited stock."
  });
});

// order
app.post("/order",(req,res)=>{
  const db = readDB();
  if(!db.storeActive) return res.json({error:"offline"});

  const order = {
    id:Date.now(),
    amount:req.body.amount,
    tracking:"VELORA"+Math.floor(Math.random()*999999)
  };

  db.orders.push(order);
  db.revenue += req.body.amount;
  saveDB(db);

  res.json(order);
});

app.listen(3000,()=>console.log("VELORA AI RUNNING"));
